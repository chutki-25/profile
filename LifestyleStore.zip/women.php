<?php
    session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Lifestyle Store</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <!-- External CSS -->
        <link rel="stylesheet" href="css/style.css" type="text/css">
    </head>
      <style>
        body{
        background-color:black;
        }
    </style>
    <body>
        <div>
            <?php
                require 'header.php';
            ?>
             <div class="container">
            <div class="jumbotron" style="margin-top: 80px;">
                <h1>Welcome to Lifestyle Store!</h1>
                <p>Because the women in you deserves better.</p>
            </div>
                 
                <div class="col-md-3 col-sm-6">
                    <a href="ethnic_w.php" class="thumbnail">
                    <img src="img/ethnic_w.jpg" alt="dress"/>
                    <div class="caption">
                        <h3>Ethnic</h3> 
                    </div>
                    </a>
                    
                      <a href="jewellery.php" class="thumbnail">
                    <img src="img/jewell.jpg" alt="sunglasses"/>
                    <div class="caption">
                        <h3>Jewellery</h3> 
                    </div>
                    </a>
                    
                </div>
                <div class="col-md-3 col-sm-6">
                    <a href="formals_w.php" class="thumbnail">
                    <img src="img/formal_w.jpg" alt="dress"/>
                    <div class="caption">
                        <h3>Formals</h3> 
                    </div>
                    </a>
                     <a href="beauty.php" class="thumbnail">
                    <img src="img/beauty.jpg" alt="beauty"/>
                    <div class="caption">
                        <h3>Beauty</h3> 
                    </div>
                    </a>
                    
                </div>
                <div class="col-md-3 col-sm-6">
                     <a href="western_w.php" class="thumbnail">
                    <img src="img/western_w.jpg" alt="dress"/>
                    <div class="caption">
                        <h3>Western</h3> 
                    
                    </div>
                    </a>
                    
                     <a href="watches_w.php" class="thumbnail">
                    <img src="img/watch_w.jpg" alt="watch"/>
                    <div class="caption">
                        <h3>Watches</h3> 
                    </div>
                    </a>
                    
                </div>   
                <div class="col-md-3 col-sm-6">
                     <a href="casual_w.php" class="thumbnail">
                    <img src="img/casual_w.jpg" alt="dress"/>
                    <div class="caption">
                        <h3>Casuals</h3> 
                    </div>
                   </a>
                     <a href="handbags.php" class="thumbnail">
                    <img src="img/bag.jpg" alt="handbags"/>
                    <div class="caption">
                        <h3>Handbags & Purses</h3> 
                    </div>
                    </a>
                </div>                    
            </div>  
            <br><br><br><br><br><br><br><br>
           <footer class="footer">
               <div class="container">
               <center>
                   <p>Copyright &copy Lifestyle Store. All Rights Reserved. | Contact Us: +91 90000 00000</p>
               </center>
               </div>
           </footer>
        </div>
    </body>
</html>
