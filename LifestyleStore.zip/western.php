<!DOCTYPE html>
<html>
    <?php
session_start();
require 'header.php';
//require 'check_if_added.php';
?>
    <head>
    <title>Lifestyle Store</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <!-- External CSS -->
        <link rel="stylesheet" href="css/style.css" type="text/css">
           <!--<script src="lifestylestore.js" async></script>-->
        
    </head>
        <script src="https://use.fontawesome.com/1274416f5a.js"></script>
      <style>
        body{
        background-color:grey;
        }
    </style>
    <body>
<div class="container">
    <div class="row">
         <div class="column">
                        <div class="thumbnail">
                                 <img src=men_western/4a.jpg style="width:100%" onclick="openModal();currentSlide(1)" class="hover-shadow cursor">
                            <center>
                                <div class="caption">
                                    <h4>Keech Men Plain Designer Shirt</h4>
                                    <p>Price: Rs. 699.00</p>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <p><a href="cart.php" role="button" class="btn btn-primary btn-block">Add to cart</a></p>
                                </div>
                            </center>
             </div>
                            
                                     <div class="thumbnail">
                                  <img src="men_western/1a.jpg" style="width:100%" onclick="openModal();currentSlide(1)" class="hover-shadow cursor">
                            <center>
                                <div class="caption">
                                    <h4>Wrogn Men Blue Slim Fit Shirt</h4>
                                    <p>Price: Rs. 659.00</p>
                                     <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star "></span>
                                    <span class="fa fa-star "></span>
                                    <p><a role="button" class="btn btn-primary btn-block">Add to cart</a></p>
                                </div>
                            </center>
                        </div>
             </div>
        
                    
            
           <div class="column">
                        <div class="thumbnail">
                                  <img src="men_western/2a.jpg" style="width:100%" onclick="openModal();currentSlide(2)" class="hover-shadow cursor">
                            <center>
                                <div class="caption">
                                    <h4>Roadster Men Slim Fit Designer Shirt</h4>
                                    <p>Price: Rs. 1119.00</p>
                                     <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star "></span>
                                    <p><a role="button" class="btn btn-primary btn-block">Add to cart</a></p>
                                </div>
                            </center>
                        </div>
                  
                        <div class="thumbnail">
                                    <img src="men_western/3a.jpg" style="width:100%" onclick="openModal();currentSlide(3)" class="hover-shadow cursor">
                            <center>
                                <div class="caption">
                                    <h4>Gap Men Slim Fit Stripe Shirt</h4>
                                    <p>Price: Rs. 1044.00</p>
                                     <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star "></span>
                                    <span class="fa fa-star "></span>
                                    <p><a role="button" class="btn btn-primary btn-block">Add to cart</a></p>
                                </div>
                            </center>
                        </div>
                    </div>
                
        <div class="column">
                        <div class="thumbnail">
                                    <img src="men_western/5a.jpg" style="width:100%" onclick="openModal();currentSlide(4)" class="hover-shadow cursor">
                            <center>
                                <div class="caption">
                                    <h4>Puma Men Slim Fit Hooded Sweatshirt</h4>
                                    <p>Price: Rs. 1999.00</p>
                                     <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star "></span>
                                    <p><a role="button" class="btn btn-primary btn-block">Add to cart</a></p>
                                </div>
                            </center>
                        </div>
   
                        <div class="thumbnail">
                                    <img src="men_western/6a.jpg" style="width:100%" onclick="openModal();currentSlide(4)" class="hover-shadow cursor">
                            <center>
                                <div class="caption">
                                    <h4>Puma Men Solid Hooded Sweatshirt</h4>
                                    <p>Price: Rs. 1199.00</p>
                                     <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star "></span>
                                    <p><a role="button" class="btn btn-primary btn-block">Add to cart</a></p>
                                </div>
                            </center>
                        </div>
                    </div>
        <div class="column">
                        <div class="thumbnail">
                                    <img src="men_western/8a.jpg" style="width:100%" onclick="openModal();currentSlide(4)" class="hover-shadow cursor">
                            <center>
                                <div class="caption">
                                    <h4>Banjos Men Printed Designer T-Shirt</h4>
                                    <p>Price: Rs.799.00</p>
                                     <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star "></span>
                                    <span class="fa fa-star "></span>
                                    <p><a role="button" class="btn btn-primary btn-block">Add to cart</a></p>
                                </div>
                            </center>
                        </div>
        
                        <div class="thumbnail">
                                    <img src="men_western/7a.jpg" style="width:100%" onclick="openModal();currentSlide(4)" class="hover-shadow cursor">
                            <center>
                                <div class="caption">
                                    <h4>Puma Men Plain Hooded Sweatshirt</h4>
                                    <p>Price: Rs. 1829.00</p>
                                     <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star checked"></span>
                                    <span class="fa fa-star "></span>
                                    <p><a role="button" class="btn btn-primary btn-block">Add to cart</a></p>
                                </div>
                            </center>
                        </div>
                    </div>

    
</div>
        </div>
                        
                    
    

        <div id="myModal" class="modal">
  <span class="close cursor" onclick="closeModal()">&times;</span>
  <div class="modal-content">

    <div class="mySlides">
      <div class="numbertext">1 / 4</div>
      <img src="img/ew_main.png" class="center" style="width:30%">
    </div>

    <div class="mySlides">
      <div class="numbertext">2 / 4</div>
      <img src="img/ew1.png" class="center" style="width:30%">
    </div>

    <div class="mySlides">
      <div class="numbertext">3 / 4</div>
      <img src="img/ew2.png" class="center" style="width:30%">
    </div>
    
    <div class="mySlides">
      <div class="numbertext">4 / 4</div>
      <img src="img/ew3.png" class="center" style="width:30%">
    </div>
    
    <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
    <a class="next" onclick="plusSlides(1)">&#10095;</a>

    <div class="caption-container">
      <p id="caption"></p>
    </div>


    <div class="column">
      <img class="demo cursor" src="img/ew_main.png" style="width:100%" onclick="currentSlide(1)" alt="Front view">
    </div>
    <div class="column">
      <img class="demo cursor" src="img/ew1.png" style="width:100%" onclick="currentSlide(2)" alt="Close up">
    </div>
    <div class="column">
      <img class="demo cursor" src="img/ew2.png" style="width:100%" onclick="currentSlide(3)" alt="Side View">
    </div>
    <div class="column">
      <img class="demo cursor" src="img/ew3.png" style="width:100%" onclick="currentSlide(4)" alt="Back view">
    </div>
  </div>
</div>
         
          <!--  <div class="column">
                        <div class="thumbnail">
                                 <img src=img/main1.png style="width:100%" onclick="openModal();currentSlide(1)" class="hover-shadow cursor">
                            <center>
                                <div class="caption">
                                    <h3>Maxi Dress</h3>
                                    <p>Price: Rs. 36000.00</p>
                                    <p><a role="button" class="btn btn-primary btn-block">Add to cart</a></p>
                                </div>
                            </center>
                        </div>
                    </div>

     <div id="myModal1" class="modal">
  <span class="close cursor" onclick="closeModal1()">&times;</span>
  <div class="modal-content">

    <div class="mySlides">
      <div class="numbertext">1 / 4</div>
      <img src="img/main1.png" class="center" style="width:30%">
    </div>

    <div class="mySlides">
      <div class="numbertext">2 / 4</div>
      <img src="img/img1.png" class="center" style="width:30%">
    </div>

    <div class="mySlides">
      <div class="numbertext">3 / 4</div>
      <img src="img/img3.png" class="center" style="width:30%">
    </div>
    
    <div class="mySlides">
      <div class="numbertext">4 / 4</div>
      <img src="img/img4.png" class="center" style="width:30%">
    </div>
    
    <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
    <a class="next" onclick="plusSlides(1)">&#10095;</a>

    <div class="caption-container">
      <p id="caption"></p>
    </div>


    <div class="column">
      <img class="demo cursor" src="img/main1.png" style="width:100%" onclick="currentSlide(1)" alt="Front view">
    </div>
    <div class="column">
      <img class="demo cursor" src="img/img1.png" style="width:100%" onclick="currentSlide(2)" alt="Close up">
    </div>
    <div class="column">
      <img class="demo cursor" src="img/img3.png" style="width:100%" onclick="currentSlide(3)" alt="Side View">
    </div>
    <div class="column">
      <img class="demo cursor" src="img/img4.png" style="width:100%" onclick="currentSlide(4)" alt="Back view">
    </div>
  </div>
</div>-->

        
<style>
body {
  font-family: Verdana, sans-serif;
  margin: 0;
}

* {
  box-sizing: border-box;
}

.row > .column {
  padding: 0 8px;
}

.row:after {
  content: "";
  display: table;
  clear: both;
}

.column {
  float: left;
  width: 25%;
}

/* The Modal (background) */
.modal {
  display: none;
  position: fixed;
  z-index: 1;
  padding-top: 50px;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  overflow: auto;
  background-color: black;
}

/* Modal Content */
.modal-content {
  position: relative;
  background-color: black;
  margin: auto;
  padding: 0;
  width: 90%;
  max-width: 1200px;
}

/* The Close Button */
.close {
  color: white;
  position: absolute;
  top: 10px;
  right: 25px;
  font-size: 35px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: #999;
  text-decoration: none;
  cursor: pointer;
}

.mySlides {
  display: none;
}

.cursor {
  cursor: pointer;
}

/* Next & previous buttons */
.prev,
.next {
  cursor: pointer;
  position: absolute;
  top: 50%;
  width: auto;
  padding: 16px;
  margin-top: -50px;
  color: white;
  font-weight: bold;
  font-size: 20px;
  transition: 0.6s ease;
  border-radius: 0 3px 3px 0;
  user-select: none;
  -webkit-user-select: none;
}

/* Position the "next button" to the right */
.next {
  right: 0;
  border-radius: 3px 0 0 3px;
}

/* On hover, add a black background color with a little bit see-through */
.prev:hover,
.next:hover {
  background-color: rgba(0, 0, 0, 0.8);
}

/* Number text (1/3 etc) */
.numbertext {
  color: #f2f2f2;
  font-size: 12px;
  padding: 8px 12px;
  position: absolute;
  top: 0;
}

img {
  margin-bottom: -4px;
}

.caption-container {
  text-align: center;
  background-color: black;
  padding: 2px 16px;
  color: white;
}

.demo {
  opacity: 0.6;
}

.active,
.demo:hover {
  opacity: 1;
}

img.hover-shadow {
  transition: 0.3s;
}

.hover-shadow:hover {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
}
    
.center {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 50%;
}
    
.checked{
    color: orange;
    }
</style>

<script>
function openModal() {
  document.getElementById("myModal").style.display = "block";
}

function closeModal() {
  document.getElementById("myModal").style.display = "none";
}

var slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
  showSlides(slideIndex += n);
}

function currentSlide(n) {
  showSlides(slideIndex = n);
}

function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  var captionText = document.getElementById("caption");
  if (n > slides.length) {slideIndex = 1}
  if (n < 1) {slideIndex = slides.length}
  for (i = 0; i < slides.length; i++) {
      slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
      dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
  captionText.innerHTML = dots[slideIndex-1].alt;
}
</script>
    
</body>
</html>
