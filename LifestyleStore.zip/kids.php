<?php
session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Lifestyle Store</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <!-- External CSS -->
        <link rel="stylesheet" href="css/style.css" type="text/css">
    </head>
      <style>
        body{
        background-color:black;
        }
    </style>
    <body>
        <div>
           <?php
            require 'header.php';
           ?>
        
        <div class="container">
            <div class="row">
                <div class="col-sm-4">
                    <a href="boys.php" class="thumbnail">
                        <img  class="img-responsive img-resize" src="img/boy.jpg" alt="boy"/>
                        <div class="caption">
                           <h3>Boys</h3> 
                                <p>"Little boys are just outdated men yet to embark on the adventures of life.".</p>
                        </div>
                    </a>
                </div>
                <div class="col-sm-4">
                    <a href="girls.php" class="thumbnail">
                        <img  class="img-responsive img-resize"  src="img/girl.jpg" alt="girl"/>
                        <div class="caption">
                           <h3>Girls</h3> 
                           <p>"For the Daddy's princess today, A queen to be tomorrow."</p>
                        </div>      
                    </a>
                </div>
                
                 <div class="col-sm-4">
                    <a href="babies.php" class="thumbnail">
                        <img  class="img-responsive img-resize" src="img/baby.png" alt="baby"/>
                        <div class="caption">
                           <h3>Babies</h3> 
                                <p>"For the little feet that make the biggest footprints in our heart!"</p>
                        </div>
                    </a>
                </div>
                 
                </div>
            </div>
            <br><br> <br><br><br><br>
           <footer class="footer"> 
               <div class="container">
               <center>
                   <p>Copyright &copy Lifestyle Store. All Rights Reserved. | Contact Us: +91 90000 00000</p>
               </center>
               </div>
           </footer>
        </div>
      </div>
    </body>
</html>