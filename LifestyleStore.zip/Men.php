<?php
    session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Lifestyle Store</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <!-- External CSS -->
        <link rel="stylesheet" href="css/style.css" type="text/css">
    </head>
    <style>
        body{
        background-color:black;
        }
    </style>
    <body>
        <div>
            <?php
                require 'header.php';
            ?>
             <div class="container">
            <div class="jumbotron" style="margin-top: 80px;">
                <h1>Welcome to Lifestyle Store!</h1>
                <p>The one place destination for the lifestyle in men.</p>
            </div>
                 
                <div class="col-md-3 col-sm-6">
                    <a href="ethnic.php" class="thumbnail">
                    <img src="img/ethnic.jpg" alt="dress"/>
                    <div class="caption">
                        <h3>Ethnic</h3> 
                    </div>
                    </a>
                    
                      <a href="men_sun.php" class="thumbnail">
                    <img src="img/men_glasses.jpg" alt="sunglasses"/>
                    <div class="caption">
                        <h3>Sunglasses</h3> 
                    </div>
                    </a>
                    
                </div>
                <div class="col-md-3 col-sm-6">
                    <a href="formals.php" class="thumbnail">
                    <img src="img/formals.jpg" alt="dress"/>
                    <div class="caption">
                        <h3>Formals</h3> 
                    </div>
                    </a>
                     <a href="groom.php" class="thumbnail">
                    <img src="img/grooming.jpg" alt="grooming"/>
                    <div class="caption">
                        <h3>Grooming</h3> 
                    </div>
                    </a>
                    
                </div>
                <div class="col-md-3 col-sm-6">
                     <a href="casual.php" class="thumbnail">
                    <img src="img/casual.jpg" alt="dress"/>
                    <div class="caption">
                        <h3>Casuals</h3> 
                    </div>
                    </a>
                    
                     <a href="men_watch.php" class="thumbnail">
                    <img src="img/watch_men.jpg" alt="watch"/>
                    <div class="caption">
                        <h3>Watches</h3> 
                    </div>
                    </a>
                    
                </div>   
                <div class="col-md-3 col-sm-6">
                     <a href="western.php" class="thumbnail">
                    <img src="img/western.jpg" alt="camera"/>
                    <div class="caption">
                        <h3>Western</h3> 
                    </div>
                   </a>
                     <a href="wallets.php" class="thumbnail">
                    <img src="img/wallet.jpg" alt="wallets"/>
                    <div class="caption">
                        <h3>Wallets</h3> 
                    </div>
                    </a>
                </div>                    
            </div>  
            <br><br><br><br><br><br><br><br>
           <footer class="footer">
               <div class="container">
               <center>
                   <p>Copyright &copy Lifestyle Store. All Rights Reserved. | Contact Us: +91 90000 00000</p>
               </center>
               </div>
           </footer>
        </div>
    </body>
</html>
