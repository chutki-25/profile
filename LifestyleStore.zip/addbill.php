<!DOCTYPE html>
<html>
<head>
	<title>Bill</title>
	<link rel="stylesheet" type="text/css" href="menu.css">
	<style type="text/css">
		body{
	background-image: url(plain.jpg);
	background-size: cover;
}
	</style>
	
	
</head>
<body>
	<div class="bill">

	<?php

	$rno=$_GET["rno"];

	require_once("connect.php");

	$q1="select * from customer where room_no=$rno";
	$res1=mysqli_query($dbc,$q1);
	$row1=mysqli_fetch_assoc($res1);

	$cid=$row1["c_id"];

	$info="<h3>Online Cloth Store</h3><p>Bill Receipt</p><p>Customer ID:{$row1["c_id"]}</p><p>Customer Name:{$row1["c_name"]}</p><p>Address:{$row1["address"]}</p><p>Phone Number:{$row1["phno"]}</p><p>Days of Stay:{$row1["days"]}</p>";

	$que="select * from room where r_id={$row1["r_id"]}";
	$res=mysqli_query($dbc,$que);
	$rown=mysqli_fetch_assoc($res);

	$info.="<p>Room Type:{$rown["r_cat"]}</p><p>Food Ordered:</p><ul>";
	$roomrent=$rown["cost"]*$row1["days"];
	$q2="select * from orders where c_id=$cid";
	$amount=0;
	$res2=mysqli_query($dbc,$q2);
	while($row=mysqli_fetch_assoc($res2))
	{
		$q3="select * from foodmenu where f_id={$row["f_id"]}";
		$res=mysqli_query($dbc,$q3);
		$r=mysqli_fetch_assoc($res);
		$amount+=$row["count"]*$r["cost"];
		$info.="<li>{$r["fname"]}-{$row["count"]}</li>";
	}
	$info.="<ul><p>Food Bill:Rs.$amount</p><p>Advance paid:{$row1["advance"]}</p>";
	$info.="<p>Room Rent:$roomrent</p>";

	$balance=$amount+$roomrent-$row1["advance"];
	$info.="<p>Balance need to be Paid:Rs.$balance</p>";

	$finalq="INSERT into bill values ({$row1["c_id"]},null,$rno,$amount)";
	mysqli_query($dbc,$finalq) or die("failed to generate bill");

	 $clear="update customer set room_no=null where room_no=$rno";
	 mysqli_query($dbc,$clear) or die("failed to check Out");
	//$del="delete from customer where room_no=$rno";
	//mysqli_query($dbc,$del) or die("failed to move customer");

	echo $info;

	echo "<a href='menu.html'>Go Back To Menu</a>";
	?>
		
	</div>
</body>
</html>