<?php
$con= mysqli_connect("localhost","root","") or die(mysqli_error($con));
$con->select_db("store") or die("Error selecting the Database");
if (isset($_SESSION['email'])) { header('location: index.php'); }
?>